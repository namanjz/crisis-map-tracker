import React, { useState } from 'react';
import './styles.css';

export default function App() {
  const [text, setText] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const analyze = async () => {
    setLoading(true);
    const response = await fetch('https://<YOUR-REPLIT-URL>.replit.app/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text })
    });

    const data = await response.json();
    setResult(data);
    setLoading(false);
  };

  return (
    <div className="container">
      <h1>🌍 CrisisMapAI</h1>
      <p>Paste a news article below to detect crisis events, sentiments, and locations.</p>
      <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Enter news article..."/>
      <button onClick={analyze} disabled={loading}>
        {loading ? 'Analyzing...' : 'Analyze Article'}
      </button>

      {result && (
        <div className="result">
          <h2>🧠 Results:</h2>
          <p><strong>Crisis Type:</strong> {result.crisis_type}</p>
          <p><strong>Sentiment:</strong> {result.sentiment}</p>
          <p><strong>Summary:</strong> {result.summary}</p>
          <h3>📍 Locations:</h3>
          <ul>
            {result.locations.map((loc, index) => (
              <li key={index}>{loc.name} — ({loc.lat.toFixed(2)}, {loc.lon.toFixed(2)})</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
